# Mobile Carb Check - Deployment Guide

1.  **GitHub:** Upload all files to a new repository.
2.  **Vercel:** Import that repository.
    *   Set Environment Variable `API_KEY` to your Gemini API Key.
3.  **Squarespace:** Add A Record `76.76.21.21` and CNAME `cname.vercel-dns.com`.
